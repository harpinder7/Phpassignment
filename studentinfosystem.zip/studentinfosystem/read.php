<?php 

session_start();

require 'connect.php';
require 'functions.php';

$query = "SELECT * FROM students";
$result = mysqli_query($con, $query);

?>

<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Student Information System</title>

  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  
</head>
<body>

  <?php include 'header.php'; ?>

  <section class="center-text">
    
    <strong>Users</strong>

    <table class="table">
      <thead>
        <tr>
          <th>Username</th>
          <th>Student Number</th>
          <th>Image</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Course</th>
          <th>Year Level</th>
          <th>Date Joined</th>
        </tr>
      </thead>
      <tbody>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['studentno']; ?></td>
            <td> <img src="img/<?php echo $row["image"]; ?>" width = 200 title="<?php echo $row['image']; ?>"> </td>
            <td><?php echo $row['firstname']; ?></td>
            <td><?php echo $row['lastname']; ?></td>
            <td><?php echo $row['course']; ?></td>
            <td><?php echo $row['yrlevel']; ?></td>
            <td><?php echo $row['date_joined']; ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>

    <a href="index.php">Go back</a>

  </section>

  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  
</body>
</html>

