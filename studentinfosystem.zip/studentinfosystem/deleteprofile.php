<?php
  session_start();

  require 'connect.php';

  if(isset($_SESSION['username'], $_SESSION['password'])) {

    $query = "DELETE FROM students WHERE username = '".$_SESSION['username']."' AND password = '".$_SESSION['password']."'";

    if(mysqli_query($con, $query)) {
      session_destroy();
      header("location:index.php");
      exit;
    } else {
      $_SESSION['prompt'] = "Error deleting profile. Please try again.";
      header("location:profile.php");
      exit;
    }

  } else {
    header("location:index.php");
    exit;
  }

  mysqli_close($con);
?>
