<footer class="page-footer">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <h4>About Us</h4>
        <p>We are a student information system that aims to provide easy access to information for students and teachers alike.</p>
      </div>
      <div class="col-md-4">
        <h4>Contact Us</h4>
        <p>Email: info@sis.com<br>Phone: +1 555-555-5555<br>Address: 123 Main St, Anytown, USA</p>
      </div>
      <div class="col-md-4">
        <h4>Connect With Us</h4>
        <p>Follow us on social media:<br>
        <a href="#">Facebook</a><br>
        <a href="#">Twitter</a><br>
        <a href="#">Instagram</a></p>
      </div>
    </div>
  </div>
  <div class="container">
    <p>&copy; 2023 Student Information System. All rights reserved.</p>
  </div>
</footer>